number = input("Enter number: ")
for i in range(len(number) - 1, -1, -1):
    print(number[i], end='')